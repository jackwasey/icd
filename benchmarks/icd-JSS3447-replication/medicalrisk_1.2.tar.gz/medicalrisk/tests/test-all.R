library(testthat)
library(medicalrisk)

test_package("medicalrisk")
